import com.google.java.contract.PreconditionError;
import com.google.java.contract.Requires;

public class Account {
	private int balance;
	private int overdraft;

	// must return balance
	public int getBalance() {
		// write code here
		return this.balance;
	}
	// constructor must not accept negative initial balances
	// it must also store the initial balance
	public Account(int initialBalance) {
		this.balance = initialBalance;
	}
	// two values constructor for the overdraft challange question 
	// must fix the testfile with additional test for overdraft for the withdraw() method
	@Requires({"initialBalance >= 0", "overdraft >= 0"})
	public Account(int initialBalance, int overdraft) {
		// write code here
		this.balance = initialBalance;
		this.overdraft = overdraft;
	}

	// deposit must only accept positive, non-zero amounts
	// it must update balance to the correct value
	@Requires({"amount > 0"})
	public void deposit(int amount) {
		// write code here
		balance += amount;
	}

	// withdraw must only accept positive, non-zero amounts
	// it must only accept amounts that do not lead to negative balances
	// it must update balance to the correct value
	@Requires({ "amount > 0", "(balance - amount) >= -overdraft"}) // amount < (balance + overdraft)
	public void withdraw(int amount) {
		// write code here
		balance -= amount;
	}

	// transfer must only accept positive, non-zero amounts
	// it must only accept inputs that do not lead to negative balances
	// it must update the balances of both accounts to the correct values
	@Requires({ "from.getBalance() > amount", "amount > 0" })
	public static void transfer(Account from, Account to, int amount) {
		// write code here using withdraw and deposit
		from.withdraw(amount);
		to.deposit(amount);
	}
}
